import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import {
  FileText,
  Mail,
  Phone,
  User,
  Banknote,
  Image as ImageIcon,
  Calendar,
  Eye,
  Inbox,
  AlertCircle,
  Loader2,
} from "lucide-react";

type Application = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  amount: string;
  description: string;
  imageKey: string | null;
  imageUrl: string | null;
  createdAt: number;
};

export default function Admin() {
  const { user, loading } = useAuth();
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { data: applications, isLoading, error: listError } = trpc.application.list.useQuery(
    undefined,
    { enabled: !!user && user.role === "admin" },
  );

  const { data: selectedApp, isLoading: detailLoading, error: detailError } = trpc.application.getById.useQuery(
    { id: selectedId! },
    { enabled: selectedId !== null },
  );

  if (loading || isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (listError) {
    return (
      <DashboardLayout>
        <Card className="border-0 shadow-sm">
          <CardContent className="py-12 text-center space-y-3">
            <AlertCircle className="h-10 w-10 mx-auto text-destructive" />
            <p className="text-muted-foreground">Başvurular yüklenirken bir hata oluştu.</p>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md border-0 shadow-xl">
          <CardContent className="py-12 text-center space-y-4">
            <div className="h-14 w-14 mx-auto rounded-full bg-destructive/10 flex items-center justify-center">
              <FileText className="h-6 w-6 text-destructive" />
            </div>
            <h2 className="text-xl font-semibold">Erişim Reddedildi</h2>
            <p className="text-sm text-muted-foreground">
              Bu sayfaya erişim yetkiniz bulunmamaktadır.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-serif font-semibold tracking-tight">
            Başvurular
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Tüm başvuruları buradan yönetebilirsiniz.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-0 shadow-sm bg-card">
            <CardContent className="py-4 px-5">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
                Toplam Başvuru
              </p>
              <p className="text-2xl font-semibold mt-1">
                {applications?.length ?? 0}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Applications List */}
        {!applications || applications.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-16 text-center">
              <Inbox className="h-12 w-12 mx-auto text-muted-foreground/50" />
              <p className="mt-4 text-muted-foreground">
                Henüz başvuru bulunmamaktadır.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {applications.map((app: Application) => (
              <Card
                key={app.id}
                className="border-0 shadow-sm hover:shadow-md transition-shadow duration-200 cursor-pointer group"
                onClick={() => setSelectedId(app.id)}
              >
                <CardContent className="py-4 px-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 min-w-0">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">
                          {app.fullName}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {app.email}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <Badge variant="secondary" className="font-medium">
                        {app.amount}
                      </Badge>
                      {app.imageUrl && (
                        <ImageIcon className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span className="text-xs text-muted-foreground hidden sm:inline">
                        {new Date(app.createdAt).toLocaleDateString("tr-TR")}
                      </span>
                      <Eye className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Detail Dialog */}
      <Dialog open={selectedId !== null} onOpenChange={() => setSelectedId(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl">
              Başvuru Detayı
            </DialogTitle>
          </DialogHeader>
          {detailLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          )}
          {detailError && (
            <div className="text-center py-8 space-y-2">
              <AlertCircle className="h-8 w-8 mx-auto text-destructive" />
              <p className="text-sm text-muted-foreground">Detay yüklenemedi.</p>
            </div>
          )}
          {!detailLoading && !detailError && !selectedApp && selectedId !== null && (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">Başvuru bulunamadı.</p>
            </div>
          )}
          {selectedApp && !detailLoading && (
            <div className="space-y-5 pt-2">
              <div className="grid gap-4">
                <DetailRow
                  icon={<User className="h-4 w-4" />}
                  label="Adı Soyadı"
                  value={selectedApp.fullName}
                />
                <DetailRow
                  icon={<Mail className="h-4 w-4" />}
                  label="E-posta"
                  value={selectedApp.email}
                />
                <DetailRow
                  icon={<Phone className="h-4 w-4" />}
                  label="Telefon No"
                  value={selectedApp.phone}
                />
                <DetailRow
                  icon={<Banknote className="h-4 w-4" />}
                  label="Talep Edilen Tutar"
                  value={selectedApp.amount}
                />
                <DetailRow
                  icon={<Calendar className="h-4 w-4" />}
                  label="Tarih"
                  value={new Date(selectedApp.createdAt).toLocaleString("tr-TR")}
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <p className="text-sm font-medium flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  Açıklama
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed bg-muted/50 rounded-lg p-3">
                  {selectedApp.description}
                </p>
              </div>

              {selectedApp.imageUrl && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <p className="text-sm font-medium flex items-center gap-2">
                      <ImageIcon className="h-4 w-4 text-muted-foreground" />
                      Yüklenen Resim
                    </p>
                    <img
                      src={selectedApp.imageUrl}
                      alt="Başvuru resmi"
                      className="w-full rounded-lg border object-contain max-h-64"
                    />
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 text-muted-foreground">{icon}</div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium mt-0.5">{value}</p>
      </div>
    </div>
  );
}
