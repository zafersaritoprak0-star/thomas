import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Upload, CheckCircle2, FileText } from "lucide-react";

export default function ApplicationForm() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const submitMutation = trpc.application.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Başvurunuz başarıyla gönderildi!");
    },
    onError: (error) => {
      toast.error("Başvuru gönderilemedi: " + error.message);
    },
  });

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!fullName.trim()) newErrors.fullName = "Ad Soyad alanı zorunludur.";
    if (!email.trim()) {
      newErrors.email = "E-posta alanı zorunludur.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = "Geçerli bir e-posta adresi giriniz.";
    }
    if (!phone.trim()) newErrors.phone = "Telefon numarası zorunludur.";
    if (!amount.trim()) newErrors.amount = "Talep edilen tutar zorunludur.";
    if (!description.trim()) newErrors.description = "Açıklama alanı zorunludur.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast.error("Dosya boyutu 10MB'dan küçük olmalıdır.");
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    let imageBase64: string | undefined;
    let imageName: string | undefined;
    let imageType: string | undefined;

    if (imageFile) {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1]);
        };
        reader.readAsDataURL(imageFile);
      });
      imageBase64 = base64;
      imageName = imageFile.name;
      imageType = imageFile.type;
    }

    submitMutation.mutate({
      fullName,
      email,
      phone,
      amount,
      description,
      imageBase64,
      imageName,
      imageType,
    });
  };

  const resetForm = () => {
    setFullName("");
    setEmail("");
    setPhone("");
    setAmount("");
    setDescription("");
    setImageFile(null);
    setImagePreview(null);
    setSubmitted(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <Card className="w-full max-w-lg border-0 shadow-xl">
          <CardContent className="flex flex-col items-center gap-6 py-16 px-8">
            <div className="h-16 w-16 rounded-full bg-green-50 flex items-center justify-center">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-semibold text-foreground">
                Başvurunuz Alındı
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed max-w-sm">
                Başvurunuz başarıyla iletildi. En kısa sürede sizinle iletişime geçilecektir.
              </p>
            </div>
            <Button
              onClick={resetForm}
              variant="outline"
              className="mt-4"
            >
              Yeni Başvuru Yap
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-12 relative overflow-hidden">
      {/* Türk Bayrağı Silueti - Arka Plan */}
      <div className="absolute inset-0 pointer-events-none select-none">
        <svg
          viewBox="0 0 800 600"
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] max-w-[900px] h-auto opacity-[0.08]"
        >
          {/* Ay */}
          <circle cx="320" cy="300" r="220" fill="#B91C1C" />
          <circle cx="380" cy="300" r="175" fill="#F9FAFB" />
          {/* Yıldız */}
          <polygon
            points="500,230 520,285 578,285 532,318 550,373 500,340 450,373 468,318 422,285 480,285"
            fill="#B91C1C"
          />
        </svg>
      </div>

      <div className="w-full max-w-xl relative z-10">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-serif font-semibold text-foreground tracking-tight">
            Başvuru Formu
          </h1>
          <p className="mt-3 text-muted-foreground text-sm">
            Lütfen aşağıdaki formu eksiksiz doldurup incelemeyi başlatın.
          </p>
        </div>

        {/* Form Card */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Ad Soyad */}
              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-sm font-medium text-foreground">
                  Adı Soyadı <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => { setFullName(e.target.value); setErrors(prev => ({...prev, fullName: ""})); }}
                  placeholder="Adınız ve soyadınız"
                  className={`h-11 transition-all duration-200 focus:shadow-md ${errors.fullName ? "border-destructive" : ""}`}
                />
                {errors.fullName && <p className="text-xs text-destructive">{errors.fullName}</p>}
              </div>

              {/* E-posta */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-foreground">
                  E-posta <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setErrors(prev => ({...prev, email: ""})); }}
                  placeholder="ornek@email.com"
                  className={`h-11 transition-all duration-200 focus:shadow-md ${errors.email ? "border-destructive" : ""}`}
                />
                {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
              </div>

              {/* Telefon No */}
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-sm font-medium text-foreground">
                  Telefon No <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => { setPhone(e.target.value); setErrors(prev => ({...prev, phone: ""})); }}
                  placeholder="05XX XXX XX XX"
                  className={`h-11 transition-all duration-200 focus:shadow-md ${errors.phone ? "border-destructive" : ""}`}
                />
                {errors.phone && <p className="text-xs text-destructive">{errors.phone}</p>}
              </div>

              {/* Talep Edilen Tutar */}
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-sm font-medium text-foreground">
                  Talep Edilen Tutar <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="amount"
                  value={amount}
                  onChange={(e) => { setAmount(e.target.value); setErrors(prev => ({...prev, amount: ""})); }}
                  placeholder="Örn: 50.000 TL"
                  className={`h-11 transition-all duration-200 focus:shadow-md ${errors.amount ? "border-destructive" : ""}`}
                />
                {errors.amount && <p className="text-xs text-destructive">{errors.amount}</p>}
              </div>

              {/* Açıklama */}
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium text-foreground">
                  Açıklama <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => { setDescription(e.target.value); setErrors(prev => ({...prev, description: ""})); }}
                  placeholder="Başvurunuzla ilgili detayları yazınız..."
                  rows={4}
                  className={`resize-none transition-all duration-200 focus:shadow-md ${errors.description ? "border-destructive" : ""}`}
                />
                {errors.description && <p className="text-xs text-destructive">{errors.description}</p>}
              </div>

              {/* Resim Yükleme */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Resim Yükle</Label>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 hover:bg-accent/50 transition-all duration-200 cursor-pointer group"
                >
                  {imagePreview ? (
                    <div className="space-y-3">
                      <img
                        src={imagePreview}
                        alt="Önizleme"
                        className="mx-auto max-h-40 rounded-md object-contain"
                      />
                      <p className="text-xs text-muted-foreground">
                        {imageFile?.name}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="mx-auto h-8 w-8 text-muted-foreground group-hover:text-primary transition-colors" />
                      <p className="text-sm text-muted-foreground">
                        Resim yüklemek için tıklayın
                      </p>
                      <p className="text-xs text-muted-foreground/70">
                        PNG, JPG, JPEG (maks. 10MB)
                      </p>
                    </div>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={submitMutation.isPending}
                className="w-full h-12 text-base font-medium shadow-lg hover:shadow-xl transition-all duration-200 active:scale-[0.98]"
              >
                {submitMutation.isPending ? (
                  <span className="flex items-center gap-2">
                    <span className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    Gönderiliyor...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Başvuruyu Gönder
                  </span>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Kişisel verileriniz gizlilik politikamız kapsamında korunmaktadır.
        </p>
      </div>
    </div>
  );
}
