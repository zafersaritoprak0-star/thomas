import ApplicationForm from "./ApplicationForm";

export default function Home() {
  return <ApplicationForm />;
}
